import warnings
import random
warnings.filterwarnings("ignore")
warnings.simplefilter(action='ignore', category=UserWarning)
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tempfile
import json
import logging
import argparse
import yaml
import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
from pycox.evaluation import EvalSurv
import torch
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.autograd.set_detect_anomaly(True)
import torch.nn as nn
import torch.optim as optim
from dataloader import preprocess_metadata, get_task_transforms, create_dataloaders
from utils.utils import predict_cumulative_hazards, compute_baseline_hazards
from models import CombinedModel, MLPVanillaCoxTime
from loss import TotalLoss
from sklearn.metrics import mean_absolute_error, mean_squared_error


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# 创建日志记录器
def setup_logging(log_dir, log_level=logging.INFO):
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, 'train.log')
    logging.basicConfig(filename=log_path,
                        filemode='a',
                        format='%(asctime)s - %(levelname)s - %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S',
                        level=log_level)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    logging.getLogger().addHandler(console_handler)

# 配置加载函数
def load_config(config_path):
    def include_constructor(loader, node):
        current_file_path = loader.name
        base_folder = os.path.dirname(current_file_path)
        included_file = os.path.join(base_folder, loader.construct_scalar(node))

        with open(included_file, "r") as file:
            return yaml.load(file, Loader=yaml.Loader)

    yaml.Loader.add_constructor("!include", include_constructor)

    with open(config_path, "r") as f:
        config = yaml.load(f, Loader=yaml.Loader)

    return config


# 训练函数
def train(model, train_df, val_df, labtrains, transforms, config):
  
    model.train()
    loss_fn = TotalLoss(loss_weights=config["loss_weights"])
    optimizer = optim.Adam(model.parameters(), lr=config["learning_rate"])

    train_dataloaders, val_dataloaders = create_dataloaders(train_df, val_df, transforms, config)

    for epoch in range(config["num_epochs"]):
        running_loss = 0.0
        for i, batches in enumerate(train_dataloaders):
            sign = torch.zeros((2), dtype=torch.float32)
            images, labels, times, tables, g_value = batches.values()
            types = 1 if torch.equal(g_value[0], sign) else 2
            images = None if torch.equal(images[0], sign) else torch.flatten(images, start_dim=0, end_dim=1).to(device)
            tables, times, labels, g_value = torch.flatten(tables, start_dim=0, end_dim=1).to(device), torch.flatten(times, start_dim=0, end_dim=1).to(device), torch.flatten(labels, start_dim=0, end_dim=1).to(device), g_value.to(device)                                   
            optimizer.zero_grad()
            
            loss = loss_fn(model,images,tables,times,labels,types,g_value)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        avg_loss = running_loss / len(train_dataloaders)
        # logging.info(f"Epoch [{epoch+1}/{config['num_epochs']}], Loss: {avg_loss:.4f}")
        print(f"Epoch [{epoch+1}/{config['num_epochs']}], Loss: {avg_loss:.4f}")
        
    validate(model, train_df, val_dataloaders, config, labtrains, transforms)
    logging.info('Finished Training')

def validate(model, train_df, val_dataloaders, config, labtrans, transforms):
    model.eval()
    with torch.no_grad():
        true_time = []
        true_label = []
        surv_full = {}
        
        baseline_hazard = compute_baseline_hazards(train_df, model, device, transforms)
        for i, batch in enumerate(val_dataloaders):
            image = batch["image"][:,0,:,:,:].to(device) if config["image_use"] else None
            table, label, time = batch["support data"][:,0,:].to(device), batch["label"][:,0,:], batch["time"][:,0,:]
#             table, time, label = torch.flatten(table, start_dim=0, end_dim=1).to(device), torch.flatten(time, start_dim=0, end_dim=1).to(device), torch.flatten(label, start_dim=0, end_dim=1).to(device)
            true_time.append(time)
            true_label.append(label)

            surv = predict_cumulative_hazards(image, table, baseline_hazard, model, device)
            # 将每次的生存函数累加到 surv_full 字典中
            for key, value in surv.items():
                if key not in surv_full:
                    surv_full[key] = value  # 如果字典中没有该列，直接添加
                else:
                    surv_full[key] = pd.concat([surv_full[key], value], axis=1, ignore_index=True)

    true_time = np.concatenate(true_time).ravel()
    true_label = np.concatenate(true_label).ravel()
    time_grid = np.linspace(true_time.min(), true_time.max(), 100)

    c_index, brier_scores, inbll, ibs, mae_scores, rmse_scores = [], [], [], [], [], []

    for key in surv_full:
        # Transform survival probabilities
        surv_full[key] = np.exp(-surv_full[key])
        surv_full[key].index = labtrans.map_scaled_to_orig(surv_full[key].index)
        
        # Evaluate metrics
        ev = EvalSurv(surv_full[key], true_time, true_label, censor_surv='km')

        # C-index
        c_index_value = ev.concordance_td()
        c_index.append(c_index_value)

        # Brier Score
        brier_score_value = ev.brier_score(time_grid)
        brier_scores.append(brier_score_value)

        # Integrated Negative Log-Likelihood (INBLL)
        inbll_value = ev.nbll(time_grid)
        inbll.append(inbll_value)

        # Integrated Brier Score (IBS)
        ibs_value = ev.integrated_brier_score(time_grid)
        ibs.append(ibs_value)

        # Mean Absolute Error (MAE)
        predicted_times = surv_full[key].apply(lambda x: x[x < 0.5].index.min(), axis=0)
        # 如果某列没有满足条件的时间点，默认使用最大时间点
        predicted_times = predicted_times.fillna(surv_full[key].index.max())
        mae_value = mean_absolute_error(true_time, predicted_times)
        mae_scores.append(mae_value)

        # Root Mean Squared Error (RMSE)
        rmse_value = mean_squared_error(true_time, predicted_times, squared=False)
        rmse_scores.append(rmse_value)

    print(f"Validation C-index: {c_index}")
    print(f"Validation Brier Score: {brier_scores}")
    print(f"Validation INBLL: {inbll}")
    print(f"Validation IBS: {ibs}")
    print(f"Validation MAE: {mae_scores}")
    print(f"Validation RMSE: {rmse_scores}")
    
    results = {
        "C-index": pd.Series(c_index).reindex(range(100), fill_value=0),
        "Brier Score": pd.Series(brier_scores),
        "INBLL": pd.Series(inbll),
        "IBS": pd.Series(ibs).reindex(range(100), fill_value=0),
        "MAE": pd.Series(mae_scores).reindex(range(100), fill_value=0),
        "RMSE": pd.Series(rmse_scores).reindex(range(100), fill_value=0)
    }
    
    

    results_df = pd.DataFrame(results)
    file_name = f"{config['dataset_name']}_validation_results.csv"
    results_df.to_csv(file_name, index=False)
    
    print(len(pd.Series(inbll)))

        

# 模型检查点保存函数
def save_checkpoint(model, config, loss):
    checkpoint_dir = f"./checkpoint/{loss:.4f}"
    os.makedirs(checkpoint_dir, exist_ok=True)
    
    # 保存模型状态字典
    model_path = os.path.join(checkpoint_dir, "best_model.pth")
    torch.save(model.state_dict(), model_path)

    # 保存 config 日志文件
    config_path = os.path.join(checkpoint_dir, "config_log.json")
    with open(config_path, 'w') as config_file:
        json.dump(config, config_file, indent=4)

    logging.info(f"Checkpoint saved to {checkpoint_dir}")

# 主函数
def main(config):
    log_dir = config['log_dir'] if 'log_dir' in config else './logs'
    setup_logging(log_dir)
    
    try:
        train_df, val_df, labtrains = preprocess_metadata(config)
        transforms = get_task_transforms(config) if config["image_use"] else None
        model = CombinedModel(config)
        model.to(device)
        if torch.cuda.device_count() > 1:
            model = nn.DataParallel(model)
        train(model, train_df, val_df, labtrains, transforms, config)

    except Exception as e:
        logging.exception(f"An error occurred during training: {str(e)}")
        


if __name__ == "__main__":
    #set_seed(123)
    parser = argparse.ArgumentParser(description="Combined model training script")
    parser.add_argument('--config', default="configs/config.yaml", type=str, help="Path to the config file")
    args = parser.parse_args()

    config = load_config(args.config)
    
    logging.info("------------------configs-------------------")
    logging.info(config)
    logging.info("--------------------------------------------")
    
    main(config)
