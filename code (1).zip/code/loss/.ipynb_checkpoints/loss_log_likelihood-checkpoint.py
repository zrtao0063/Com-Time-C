import torch
import pandas as pd


class LogLikelihoodLoss:
    def __call__(self, model, image, table, time, label, eps=1e-8):
        batch_size = image.size(0)
    
        time, indices = torch.sort(time)
        image = image[indices]
        table = table[indices]
        label = label[indices]
        
        pll = torch.zeros(batch_size, device=image.device)
    
        for i in range(batch_size):
            if label[i] == 1: 
                sub_image = image[i:]
                sub_table = table[i:]
                t = time[i]
                n = sub_table.size(0)
                t_repeated = t.repeat(n)

                expg = model(sub_image, sub_table, t_repeated)
                # g_pred = model(image[i:i+1], table[i:i+1], time[i:i+1])
                # # print("expg:", expg)
                # # print("g_pred:", g_pred)
                # pll[i] = torch.exp(g_pred[:,0]) - torch.log(torch.sum(torch.exp(expg[:,0])))

                pll_elements = []
                for i in range(expg.shape[1]):
                    pll_elements.append(torch.exp(expg[0,i]) - torch.log(torch.sum(torch.exp(expg[:,i]))))

                pll[i] = torch.sum(torch.stack(pll_elements))

        pll = pll[label == 1]
    
        return -torch.mean(pll)


# class LogLikelihoodLoss:
#     def __call__(self, out, time, label, num_event, num_category, eps=1e-8):
#         device = out.device
#         batch_size = out.size(0)

#         loss = 0.0

#         for i in range(batch_size):
#             event_time = int(time[i])
#             event_type = int(label[i])
            
#             if event_type > 0:
#                 r = event_type - 1
#                 a = out[i, r, event_time]
#                 print("a:", a)
#                 survival_prob = 1 - torch.sum(out[i, :, event_time])
#                 print("survival_prob:", survival_prob)
#                 partial_derivative = a * survival_prob
#                 if partial_derivative > 0:
#                     loss += torch.log(partial_derivative)
#             else: 
#                 survival_prob = 1 - torch.sum(out[i, :, event_time])
#                 if survival_prob > 0:
#                     loss += torch.log(survival_prob)
    
#         return -loss / batch_size

        

# class LogLikelihoodLoss:
#     def __call__(self, out, time, label, num_event, num_category, eps=1e-8, alpha = 0.4):
#         device = out.device
#         batch_size = out.size(0)

#         true_label = torch.zeros(batch_size, num_event, num_category, device=device)
#         for i in range(batch_size):
#             event_idx = label[i].item()
#             category_idx = time[i].item()
#             if event_idx != 0:
#                 true_label[i, event_idx, category_idx] = 1
#             else:
#                 true_label[i, event_idx, category_idx + 1:] = 1
#         true_label = true_label.long()

        
#         S = torch.cumprod(1 - out, dim=2)
#         I_1 = (label != 0).float().unsqueeze(1).unsqueeze(1)

#         print(s.shape)
#         print(true_label.shape)
#         temp1 = torch.log(torch.gather(S, 2, true_label).clamp(min=eps))
#         uncensored_loss = -I_1 * (
#             torch.log(torch.gather(S, 2, true_label).clamp(min=eps)) + torch.log(torch.gather(out, 2, true_label).clamp(min=eps))
#         )
#         print(uncensored_loss)
#         censored_loss = -(1-I_1) * torch.log(torch.gather(S, 1, true_label + 1).clamp(min=eps))
#         print(censored_loss)
#         neg_l = censored_loss + uncensored_loss
#         loss_1 = (1 - alpha) * neg_l + alpha * uncensored_loss
#         loss_1 = loss_1.mean()

#         return loss_1