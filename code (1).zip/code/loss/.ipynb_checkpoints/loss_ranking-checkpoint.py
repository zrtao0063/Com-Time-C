import torch
import torch.nn.functional as F

class RankingLoss:
    def __call__(self, out, time, label, num_event, num_category):
        
        device = out.device
        fc_mask2 = torch.zeros(out.size(0), num_category).to(device)
        for i in range(out.size(0)):
            event_idx = label[i].item()
            category_idx = time[i].item()
            fc_mask2[i, category_idx] = 1

        
        sigma1 = 0.1

        eta = []
        for e in range(num_event):
            one_vector = torch.ones_like(time, dtype=torch.float32)
            I_2 = (label == e + 1).float() # indicator for event
            if I_2.dim() == 0:
                I_2 = I_2.unsqueeze(0)  # Ensure I_2 is at least 1D
            I_2 = torch.diag(I_2.squeeze())
            tmp_e = out[:, e, :].view(-1, num_category) # event specific joint prob.

            R = torch.matmul(tmp_e, fc_mask2.t()) # no need to divide by each individual dominator
            diag_R = torch.diag(R)
            R = one_vector * diag_R.unsqueeze(1) - R
            R = R.t()

            T = F.relu(torch.sign(one_vector * time.t() - time * one_vector.t())).float()
            T = torch.matmul(I_2, T) # only remains T_{ij}=1 when event occurred for subject i

            tmp_eta = torch.mean(T * torch.exp(-R / sigma1), dim=1, keepdim=True)
            eta.append(tmp_eta)
        eta = torch.stack(eta, dim=1) # stack referenced on subjects
        eta = torch.mean(eta.view(-1, num_event), dim=1, keepdim=True)

        loss_2 = torch.sum(eta) # sum over num_Events
        return loss_2
