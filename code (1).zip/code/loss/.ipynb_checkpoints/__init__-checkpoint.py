from .loss_log_likelihood import LogLikelihoodLoss
from .loss_ranking import RankingLoss
from .loss_calibration import CalibrationLoss

class TotalLoss:
    def __init__(self, loss_weights=(1.0, 1.0, 1.0)):
        self.log_likelihood_loss = LogLikelihoodLoss()
        self.ranking_loss = RankingLoss()
        self.calibration_loss = CalibrationLoss()
        self.weights = loss_weights

    def __call__(self, model, image, table, time, label):
        a, b, c = self.weights
        loss = self.log_likelihood_loss(model, image, table, time, label)

        return loss
