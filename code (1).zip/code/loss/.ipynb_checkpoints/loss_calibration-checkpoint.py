import torch

class CalibrationLoss:
    def __call__(self, out, time, label, num_event, num_category):
        
        device = out.device
        fc_mask2 = torch.zeros(out.size(0), num_category).to(device)
        for i in range(out.size(0)):
            event_idx = label[i].item()
            category_idx = time[i].item()
            fc_mask2[i, category_idx] = 1

        eta = []
        for e in range(num_event):
            one_vector = torch.ones_like(time, dtype=torch.float32)
            I_2 = (label == e + 1).float().unsqueeze(1) # indicator for event
            tmp_e = out[:, e, :].view(-1, num_category) # event specific joint prob.

            r = torch.sum(tmp_e * fc_mask2, dim=0) # no need to divide by each individual dominator
            tmp_eta = torch.mean((r - I_2) ** 2, dim=0, keepdim=True)

            eta.append(tmp_eta)
        eta = torch.stack(eta, dim=1) # stack referenced on subjects
        eta = torch.mean(eta.view(-1, num_event), dim=1, keepdim=True)

        loss_3 = torch.sum(eta) # sum over num_Events
        return loss_3
