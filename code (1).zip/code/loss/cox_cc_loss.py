import torch
import torch.nn.functional as F
import random


class cox_cc_loss:
    def __call__(self, model, images, tables, times, labels, type, g_value, shrink: float = 0.):
        # 模型前向传播，获取 g_case 和 g_control
        g_all = model(images, tables, times)

        if type == 1:
            g_case = g_all[0::2]  # 前一半是 g_case
            g_control = g_all[1::2]  # 后一半是 g_control
            loss = F.softplus(g_control - g_case).mean()


        elif type == 2:
            g_case = g_all[0::3]
            g_forward = g_all[1::3]
            g_backward = g_all[2::3]
            g_value = g_value.unsqueeze(1)
            loss = (F.softplus(g_forward - g_case).flatten().mean() +
                    torch.log(1 + g_value*torch.exp(g_case - g_backward)).flatten().mean())

        # 如果需要添加正则化项
        # if shrink != 0:
        #     reg_loss = shrink * (g_all.abs().mean())
        #     loss += reg_loss

        return loss


# import torch
# import torch.nn as nn
#
# class cox_cc_loss(nn.Module):
#     def __init__(self):
#         super(cox_cc_loss, self).__init__()
#
#     def forward(self, model, images, tables, times, events, shrink: float = 0.):
#         """
#         计算 Fine-Gray 子分布部分似然损失。
#
#         参数：
#         - model: 神经网络模型，输出为 (eta1, eta2)，对应两个竞争风险的线性预测值。
#         - images: 图像数据输入，形状为 (batch_size, ...)，根据模型的需求。
#         - tables: 表格数据输入，形状为 (batch_size, ...)，根据模型的需求。
#         - times: 生存时间张量，形状为 (batch_size,)。
#         - events: 事件类型张量，形状为 (batch_size,)，取值为 0（删失）、1（风险1）、2（风险2）。
#         - shrink: L2 正则化系数，默认为 0。
#
#         返回：
#         - total_loss: 计算得到的总损失值。
#         """
#         # 获取模型输出的线性预测值
#         etas = model(images, tables, times)  # etas 的形状为 (batch_size, 2)
#         eta1 = etas[:, 0]  # 取出第一列，形状为 (batch_size,)
#         eta2 = etas[:, 1]  # 取出第二列，形状为 (batch_size,)
#
#         # 将 times 和 events 移动到与模型输出相同的设备上
#         times = times.to(eta1.device)
#         events = events.to(eta1.device)
#
#         # 构建修正风险集
#         n_samples = times.shape[0]
#         times_i = times.view(-1, 1)  # (n_samples, 1)
#         times_j = times.view(1, -1)  # (1, n_samples)
#         risk_set_mask = (times_j >= times_i).float()  # (n_samples, n_samples)
#
#         # 计算第一个风险的损失
#         loss1 = self.fine_gray_loss(eta1, events, risk_set_mask, event_type_k=1)
#         # 计算第二个风险的损失
#         loss2 = self.fine_gray_loss(eta2, events, risk_set_mask, event_type_k=2)
#
#         # 总损失
#         total_loss = loss1 + loss2
#
#         # 添加 L2 正则化项（可选）
#         if shrink > 0.:
#             l2_reg = 0.
#             for param in model.parameters():
#                 l2_reg += torch.norm(param)
#             total_loss += shrink * l2_reg
#
#         return total_loss
#
#     def fine_gray_loss(self, eta_k, events, risk_set_mask, event_type_k):
#         """
#         计算单个风险事件的 Fine-Gray 子分布部分似然损失。
#
#         参数：
#         - eta_k: 模型对风险事件 k 的线性预测值，形状为 (n_samples,)。
#         - events: 事件类型张量，形状为 (n_samples,)。
#         - risk_set_mask: 风险集掩码矩阵，形状为 (n_samples, n_samples)。
#         - event_type_k: 风险事件的类型（整数）。
#
#         返回：
#         - loss_k: 风险事件 k 的损失值。
#         """
#         n_samples = eta_k.shape[0]
#
#         # 获取事件指示变量
#         delta_k = (events == event_type_k).float()  # (n_samples,)
#
#         # 获取发生事件 k 的样本索引
#         event_idx = (events == event_type_k)
#         if event_idx.sum() == 0:
#             return torch.tensor(0., device=eta_k.device)
#
#         # 提取发生事件 k 的样本的预测值
#         eta_event = eta_k[event_idx]  # (n_events_k,)
#
#         # 提取对应的风险集掩码
#         risk_set_mask_event = risk_set_mask[event_idx, :]  # (n_events_k, n_samples)
#
#         # 计算分母：对于每个发生事件的样本 i，计算风险集中的预测值指数和
#         exp_eta = torch.exp(eta_k)  # (n_samples,)
#         denom = torch.matmul(risk_set_mask_event, exp_eta)  # (n_events_k,)
#
#         # 计算对数部分似然
#         loss_k = - torch.sum(eta_event - torch.log(denom + 1e-10))  # 加上小量防止数值问题
#
#         return loss_k
