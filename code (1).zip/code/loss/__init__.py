from .loss_log_likelihood import LogLikelihoodLoss
from .loss_ranking import RankingLoss
from .cox_cc_loss import cox_cc_loss

class TotalLoss:
    def __init__(self, loss_weights=(1.0, 1.0, 1.0)):
        self.log_likelihood_loss = LogLikelihoodLoss()
        self.ranking_loss = RankingLoss()
        self.cox_cc_loss = cox_cc_loss()
        self.weights = loss_weights

    def __call__(self, model, image, table, time, label, type, g_value):
        a, b, c = self.weights
        # loss1, pred_dict = self.log_likelihood_loss(model, image, table, time, label)
        # loss2 = self.ranking_loss(model, image, table, time, label)
        loss3 = self.cox_cc_loss(model, image, table, time, label, type, g_value)
        total_loss = c*loss3

        return loss3
