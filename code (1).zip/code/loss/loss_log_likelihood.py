import torch
import pandas as pd
import numpy as np


class LogLikelihoodLoss:
    def __call__(self, model, image, table, time, label, eps=1e-8):
        batch_size = table.size(0)
    
        time, indices = torch.sort(time)
        if image is not None:
            image = image[indices]
        table = table[indices]
        label = label[indices]
        n = np.unique(label).shape[0] - 1
        
        pll = torch.zeros((batch_size,n), device=table.device)
        expg_at_risk = torch.zeros((batch_size, n), device=table.device)
    
        for i in range(batch_size):
            if label[i] != 0:
                index = (label != 0) & (label != label[i])
                if image is not None:
                    sub_image = torch.cat((image[i:], image[index]), dim=0)
                    sub_image = torch.unique(sub_image, dim=0)
                else:
                    sub_image = None
                sub_table = torch.cat((table[i:], table[index]), dim=0)
                sub_table = torch.unique(sub_table, dim=0)
                t = time[i]
                n = sub_table.size(0)
                t_repeated = t.repeat(n)

                pg = model(sub_image, sub_table, t_repeated)
                # temp = int(label[i] - 1)
                expg =  torch.exp(pg)
                expg_at_risk[i] = expg.sum(dim=0)
                pll[i] = pg[0] - torch.log(torch.sum(expg))

        pll = pll[label != 0]
        pred_dict = torch.cat((expg_at_risk.detach(), label.detach().unsqueeze(1), time.detach().unsqueeze(1)), dim=1)
    
        return -torch.mean(pll), pred_dict