import torch
import torch.nn.functional as F

class RankingLoss:
    def __call__(self, model, image, table, time, label, eps=1e-8):
        batch_size = table.size(0)
    
        time, indices = torch.sort(time)
        if image is not None:
            image = image[indices]
        table = table[indices]
        label = label[indices]
        
        expg = model(image, table, time)
        
        loss = 0
        
        for i in range(batch_size):
            if label[i] != 0:
                for j in range(i+1, batch_size):
                    if label[j] != 0:
                        for k in range(1):
                            if expg[j, k] > expg[i, k]:
                                loss += 0.1
         
        return loss / batch_size