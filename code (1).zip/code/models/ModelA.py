import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

from .unet import UNet3D

def create_FCNet(input_dim, hidden_dim, activation_fn, num_layers, dropout_rate):
    if isinstance(activation_fn, str):
        activation_fn = getattr(nn, activation_fn)
    layers = []
    in_dim = input_dim
    for i in range(num_layers):
        layers.append(nn.Linear(in_dim, hidden_dim))
        nn.init.kaiming_normal_(layers[-1].weight, nonlinearity='relu')  # 使用Kaiming初始化
        layers.append(activation_fn())
        layers.append(nn.BatchNorm1d(hidden_dim))
        layers.append(nn.Dropout(dropout_rate))
        in_dim = hidden_dim
    layers.append(nn.Linear(in_dim, 1, bias=False))
    return nn.Sequential(*layers)

class TableDataProcessor(nn.Module):
    def __init__(self, input_dim=41, hidden_dims=[64, 128], activation_fn="ReLU", dropout_rate=0.1):
        super(TableDataProcessor, self).__init__()
        if isinstance(activation_fn, str):
            activation_fn = getattr(nn, activation_fn)
        self.layers = nn.ModuleList()
        in_dim = input_dim
        for hidden_dim in hidden_dims:
            self.layers.append(nn.Linear(in_dim, hidden_dim))
            nn.init.kaiming_normal_(self.layers[-1].weight, nonlinearity='relu')  # Kaiming初始化
            self.layers.append(activation_fn())
            self.layers.append(nn.BatchNorm1d(hidden_dim))
            self.layers.append(nn.Dropout(dropout_rate))
            in_dim = hidden_dim

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x
    
    
class TimeFeatureExtractor(nn.Module):
    def __init__(self, input_dim=1, hidden_dims=[32, 128]):
        super(TimeFeatureExtractor, self).__init__()
        self.layers = nn.ModuleList()
        in_dim = input_dim
        for hidden_dim in hidden_dims:
            self.layers.append(nn.Linear(in_dim, hidden_dim))
            self.layers.append(nn.BatchNorm1d(hidden_dim))  # 添加 Batch Normalization
            in_dim = hidden_dim

    def forward(self, x):
        for layer in self.layers:
            x = F.relu(layer(x)) if isinstance(layer, nn.Linear) else layer(x)
        return x


class CrossAttention(nn.Module):
    def __init__(self, image_input_dim=128, table_input_dim=128, hidden_dim=128):
        super(CrossAttention, self).__init__()
        self.fc_q_table = nn.Linear(table_input_dim, hidden_dim)
        self.fc_k_image = nn.Linear(image_input_dim, hidden_dim)
        self.fc_v_image = nn.Linear(image_input_dim, hidden_dim)

    def forward(self, image_features, table_features):
        k_image = self.fc_k_image(image_features)
        v_image = self.fc_v_image(image_features)
        
        q_table = self.fc_q_table(table_features)
        attended_table = F.softmax(torch.bmm(q_table.unsqueeze(1), k_image.unsqueeze(2)), dim=-1) 
        attended_table = attended_table.squeeze(1) * v_image

        combined_features = torch.cat([image_features, table_features, attended_table], dim=1)

        return combined_features




class CombinedModel(nn.Module):
    def __init__(self, config):
        super(CombinedModel, self).__init__()

        self.num_event = config["num_event"]
        self.num_category = config["num_category"]
        self.in_dim = config["num_features"]
        self.fc_hidden_dim = config["fc"]["hidden_dim"]
        self.tb_hidden_dim = config["table"]["hidden_dim"]
        self.num_layers = config["fc"]["num_layers"]
        self.active_fn = config["fc"]["active_fn"]
        self.dropout_rate = config["fc"]["dropout_rate"]
        self.mode = config["mode"] == "train"

        self.table_processor = TableDataProcessor(self.in_dim, self.tb_hidden_dim, self.active_fn, self.dropout_rate)
        self.time_extractor = TimeFeatureExtractor(input_dim=1, hidden_dims=config["time"]["hidden_dim"])
        self.cross_attention = CrossAttention()
        
        if config["image_use"]:
             self.sub_networks = nn.ModuleList([
                create_FCNet(self.tb_hidden_dim[-1] * 3, self.fc_hidden_dim, self.active_fn, self.num_layers, self.dropout_rate)
                for _ in range(self.num_event)
             ])
        else:
            self.sub_networks = nn.ModuleList([
                create_FCNet(self.tb_hidden_dim[-1], self.fc_hidden_dim, self.active_fn, self.num_layers, self.dropout_rate)
                for _ in range(self.num_event)
             ])

        self.output_fc = nn.Linear(self.num_event * self.fc_hidden_dim, self.num_event, bias = False)
        self.nnunet = UNet3D(in_channels = 1, out_channels = 1)
        self.image_fc = nn.Linear(128, 1)

    def forward(self, image_data, table_data, time):
        table_data = torch.cat([table_data, time], dim = 1)
        features = self.table_processor(table_data)
        
        if image_data is not None:
            image_data = image_data.unsqueeze(1)
            image_features = self.nnunet(image_data)
            batch_size, channels, _, _, _ = image_features.size()
            image_features = image_features.view(batch_size, channels, -1)
            image_features = self.image_fc(image_features).squeeze(2)
            features = self.cross_attention(image_features, features)

        out = []
        for sub_net in self.sub_networks:
            cs_out = sub_net(features)
            out.append(cs_out)

        out = torch.stack(out, dim = 1).squeeze(2)
        return out

import torchtuples as tt
class MLPVanillaCoxTime(nn.Module):
    def __init__(self, config, num_nodes=[32, 32], batch_norm=True, dropout=None, activation=nn.ReLU,
                 w_init=lambda w: nn.init.kaiming_normal_(w, nonlinearity='relu')):
        super().__init__()
        in_features = config["num_features"]
        out_features = config["num_event"]
        output_activation = None
        output_bias=False
        self.net = tt.practical.MLPVanilla(in_features, num_nodes, out_features, batch_norm, dropout,
                                           activation, output_activation, output_bias, w_init)

    def forward(self, image_data, table_data, time):
        time = time.view(-1, 1)
        table_data = torch.cat([table_data, time], dim=1)
        return self.net(table_data)