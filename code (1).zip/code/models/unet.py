import torch
from torch import nn
from functools import partial
from .base_model import BaseModel


def create_conv(in_channels, out_channels, kernel_size, order, num_groups, padding, is3d):
    assert 'c' in order, 'Conv layer MUST be present'
    assert order[0] not in 'rle', 'Non-linearity cannot be the first operation in the layer'
    
    modules = []
    for i, char in enumerate(order):
        if char == 'r':
            modules.append(('ReLU', nn.ReLU()))
        elif char == 'l':
            modules.append(('LeakyReLU', nn.LeakyReLU()))
        elif char == 'e':
            modules.append(('ELU', nn.ELU()))
        elif char == 'c':
            bias = not ('g' in order or 'b' in order)
            if is3d:
                conv = nn.Conv3d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, padding=padding, bias=bias)
            else:
                conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, padding=padding, bias=bias)
            modules.append(('conv', conv))
        elif char == 'g':
            is_before_conv = i < order.index('c')
            num_channels = in_channels if is_before_conv else out_channels
            if num_channels < num_groups:
                num_groups = 1
            assert num_channels % num_groups == 0, f'Expected number of channels in input to be divisible by num_groups. num_channels={num_channels}, num_groups={num_groups}'
            modules.append(('groupnorm', nn.GroupNorm(num_groups=num_groups, num_channels=num_channels)))
        elif char == 'b':
            is_before_conv = i < order.index('c')
            bn = nn.BatchNorm3d if is3d else nn.BatchNorm2d
            modules.append(('batchnorm', bn(in_channels) if is_before_conv else bn(out_channels)))
        else:
            raise ValueError(f"Unsupported layer type '{char}'. MUST be one of ['b', 'g', 'r', 'l', 'e', 'c']")
    
    return modules


class SingleConv(nn.Sequential):

    def __init__(self, in_channels, out_channels, kernel_size=3, order='gcr', num_groups=8, padding=1, is3d=True):
        super(SingleConv, self).__init__()
        for name, module in create_conv(in_channels, out_channels, kernel_size, order, num_groups, padding, is3d):
            self.add_module(name, module)


class DoubleConv(nn.Sequential):

    def __init__(self, in_channels, out_channels, encoder, kernel_size=3, order='gcr', num_groups=8, padding=1, is3d=True):
        super(DoubleConv, self).__init__()
        self.in_channels = in_channels
        if encoder:
            conv1_in_channels = in_channels
            conv1_out_channels = out_channels // 2
            conv1_out_channels = max(conv1_out_channels, in_channels)
            conv2_in_channels, conv2_out_channels = conv1_out_channels, out_channels
        else:
            conv1_in_channels, conv1_out_channels = in_channels, out_channels
            conv2_in_channels, conv2_out_channels = out_channels, out_channels
        
        self.add_module('SingleConv1', SingleConv(conv1_in_channels, conv1_out_channels, kernel_size, order, num_groups, padding=padding, is3d=is3d))
        self.add_module('SingleConv2', SingleConv(conv2_in_channels, conv2_out_channels, kernel_size, order, num_groups, padding=padding, is3d=is3d))


class Encoder(nn.Module):

    def __init__(self, in_channels, out_channels, conv_kernel_size=3, apply_pooling=True, pool_kernel_size=2, pool_type='max', basic_module=DoubleConv, conv_layer_order='gcr', num_groups=8, padding=1, is3d=True):
        super(Encoder, self).__init__()
        assert pool_type in ['max', 'avg']
        if apply_pooling:
            if pool_type == 'max':
                self.pooling = nn.MaxPool3d(kernel_size=pool_kernel_size) if is3d else nn.MaxPool2d(kernel_size=pool_kernel_size)
            else:
                self.pooling = nn.AvgPool3d(kernel_size=pool_kernel_size) if is3d else nn.AvgPool2d(kernel_size=pool_kernel_size)
        else:
            self.pooling = None
        
        self.basic_module = basic_module(in_channels, out_channels, encoder=True, kernel_size=conv_kernel_size, order=conv_layer_order, num_groups=num_groups, padding=padding, is3d=is3d)

    def forward(self, x):
        if self.pooling is not None:
            x = self.pooling(x)
            
        x = self.basic_module(x)
        return x


class Decoder(nn.Module):

    def __init__(self, in_channels, out_channels, conv_kernel_size=3, scale_factor=(2, 2, 2), basic_module=DoubleConv, conv_layer_order='gcr', num_groups=8, mode='nearest', padding=1, upsample=True, is3d=True):
        super(Decoder, self).__init__()
        if upsample:
            if basic_module == DoubleConv:
                self.upsampling = InterpolateUpsampling(mode=mode)
                self.joining = partial(self._joining, concat=True)
            else:
                self.upsampling = TransposeConvUpsampling(in_channels=in_channels, out_channels=out_channels, kernel_size=conv_kernel_size, scale_factor=scale_factor)
                self.joining = partial(self._joining, concat=False)
                in_channels = out_channels
        else:
            self.upsampling = NoUpsampling()
            self.joining = partial(self._joining, concat=True)
        
        self.basic_module = basic_module(in_channels, out_channels, encoder=False, kernel_size=conv_kernel_size, order=conv_layer_order, num_groups=num_groups, padding=padding, is3d=is3d)

    def forward(self, encoder_features, x):
        x = self.upsampling(encoder_features=encoder_features, x=x)
        x = self.joining(encoder_features, x)
        x = self.basic_module(x)
        return x

    @staticmethod
    def _joining(encoder_features, x, concat):
        return torch.cat((encoder_features, x), dim=1) if concat else encoder_features + x


def create_encoders(in_channels, f_maps, basic_module, conv_kernel_size, conv_padding, layer_order, num_groups, pool_kernel_size, is3d):
    encoders = []
    for i, out_feature_num in enumerate(f_maps):
        if i == 0:
            encoder = Encoder(in_channels, out_feature_num, apply_pooling=False, basic_module=basic_module, conv_layer_order=layer_order, conv_kernel_size=conv_kernel_size, num_groups=num_groups, padding=conv_padding, is3d=is3d)
        else:
            encoder = Encoder(f_maps[i - 1], out_feature_num, basic_module=basic_module, conv_layer_order=layer_order, conv_kernel_size=conv_kernel_size, num_groups=num_groups, pool_kernel_size=pool_kernel_size, padding=conv_padding, is3d=is3d)
        encoders.append(encoder)
    return nn.ModuleList(encoders)


def create_decoders(f_maps, basic_module, conv_kernel_size, conv_padding, layer_order, num_groups, is3d):
    decoders = []
    reversed_f_maps = list(reversed(f_maps))
    for i in range(len(reversed_f_maps) - 1):
        in_feature_num = reversed_f_maps[i] + reversed_f_maps[i + 1] if basic_module == DoubleConv else reversed_f_maps[i]
        out_feature_num = reversed_f_maps[i + 1]
        decoder = Decoder(in_feature_num, out_feature_num, basic_module=basic_module, conv_layer_order=layer_order, conv_kernel_size=conv_kernel_size, num_groups=num_groups, padding=conv_padding, is3d=is3d)
        decoders.append(decoder)
    return nn.ModuleList(decoders)


class AbstractUpsampling(nn.Module):

    def __init__(self, upsample):
        super(AbstractUpsampling, self).__init__()
        self.upsample = upsample

    def forward(self, encoder_features, x):
        output_size = encoder_features.shape[2:]
        return self.upsample(x, size=output_size)


class InterpolateUpsampling(AbstractUpsampling):

    def __init__(self, mode='nearest'):
        upsample = partial(nn.functional.interpolate, mode=mode)
        super().__init__(upsample)


class TransposeConvUpsampling(AbstractUpsampling):

    def __init__(self, in_channels=None, out_channels=None, kernel_size=3, scale_factor=(2, 2, 2)):
        upsample = nn.ConvTranspose3d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=scale_factor, padding=1)
        super().__init__(upsample)


class NoUpsampling(AbstractUpsampling):

    def __init__(self):
        super().__init__(self._no_upsampling)

    @staticmethod
    def _no_upsampling(x, size):
        return x


def number_of_features_per_level(init_channel_number, num_levels):
    return [(init_channel_number * 2 ** k) for k in range(num_levels)]


class UNet3D(BaseModel):

    def __init__(self, in_channels, out_channels, f_maps=8, layer_order='gcr', num_groups=1, num_levels=5, is3d=True, conv_padding=1, basic_module=DoubleConv, conv_kernel_size=3, pool_kernel_size=2):
        super(UNet3D, self).__init__()
        if isinstance(f_maps, int):
            f_maps = number_of_features_per_level(f_maps, num_levels)
        
        self.encoders = create_encoders(in_channels, f_maps, basic_module, conv_kernel_size, conv_padding, layer_order, num_groups, pool_kernel_size, is3d=is3d)
        self.decoders = create_decoders(f_maps, basic_module, conv_kernel_size, conv_padding, layer_order, num_groups, is3d=is3d)
        self.final_conv = nn.Conv3d(f_maps[0], out_channels, 1) if is3d else nn.Conv2d(f_maps[0], out_channels, 1)

    def forward(self, x):
        encoder_features = []
        for encoder in self.encoders:
            x = encoder(x)
            encoder_features.insert(0, x)
        
#         for i, decoder in enumerate(self.decoders):
#             x = decoder(encoder_features[i + 1], x)
        
#         x = self.final_conv(x)
        return x
