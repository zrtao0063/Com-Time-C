import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

from .swin_unetr import SwinUNETR
from .unet import UNet3D

def create_FCNet(input_dim, hidden_dim, output_dim, activation_fn, num_layers, dropout_rate):
    if isinstance(activation_fn, str):
        activation_fn = getattr(nn, activation_fn)
    layers = []
    in_dim = input_dim
    for i in range(num_layers):
        layers.append(nn.Linear(in_dim, hidden_dim))
        nn.init.kaiming_normal_(layers[-1].weight, nonlinearity='relu')  # 使用Kaiming初始化
        #layers.append(nn.BatchNorm1d(hidden_dim))
        layers.append(activation_fn())
        layers.append(nn.Dropout(dropout_rate))
        in_dim = hidden_dim
    layers.append(nn.Linear(in_dim, output_dim))  # 最后一层没有激活函数
    nn.init.kaiming_normal_(layers[-1].weight, nonlinearity='linear')  # 最后一层也进行初始化
    return nn.Sequential(*layers)

class TableDataProcessor(nn.Module):
    def __init__(self, input_dim=41, hidden_dims=[64, 128], output_dim=1, activation_fn="ReLU"):
        super(TableDataProcessor, self).__init__()
        if isinstance(activation_fn, str):
            activation_fn = getattr(nn, activation_fn)
        self.layers = nn.ModuleList()
        in_dim = input_dim
        for hidden_dim in hidden_dims:
            self.layers.append(nn.Linear(in_dim, hidden_dim))
            nn.init.kaiming_normal_(self.layers[-1].weight, nonlinearity='relu')  # Kaiming初始化
            #self.layers.append(nn.BatchNorm1d(hidden_dim))
            self.layers.append(activation_fn())
            in_dim = hidden_dim
        
        # 最后一层没有激活函数
        self.output_layer = nn.Linear(in_dim, output_dim)
        nn.init.kaiming_normal_(self.output_layer.weight, nonlinearity='linear')  # 最后一层初始化

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        x = self.output_layer(x)  # 最后一层没有激活函数
        return x
    
    
class TimeFeatureExtractor(nn.Module):
    def __init__(self, input_dim=1, hidden_dims=[32, 128]):
        super(TimeFeatureExtractor, self).__init__()
        self.layers = nn.ModuleList()
        in_dim = input_dim
        for hidden_dim in hidden_dims:
            self.layers.append(nn.Linear(in_dim, hidden_dim))
            self.layers.append(nn.BatchNorm1d(hidden_dim))  # 添加 Batch Normalization
            in_dim = hidden_dim

    def forward(self, x):
        for layer in self.layers:
            x = F.relu(layer(x)) if isinstance(layer, nn.Linear) else layer(x)
        return x


class CrossAttention(nn.Module):
    def __init__(self, image_input_dim=128, table_input_dim=128, hidden_dim=128):
        super(CrossAttention, self).__init__()
#         self.fc_q_image = nn.Linear(image_input_dim, hidden_dim)
        self.fc_q_table = nn.Linear(table_input_dim, hidden_dim)
        self.fc_k_image = nn.Linear(image_input_dim, hidden_dim)
        self.fc_v_image = nn.Linear(image_input_dim, hidden_dim)
#         self.fc_k_table = nn.Linear(table_input_dim, hidden_dim)
#         self.fc_v_table = nn.Linear(table_input_dim, hidden_dim)

    def forward(self, image_features, table_features):
        # Generate queries, keys, and values
#         q_image = self.fc_q_image(image_features)
        k_image = self.fc_k_image(image_features)
        v_image = self.fc_v_image(image_features)
        
        q_table = self.fc_q_table(table_features)
#         k_table = self.fc_k_table(table_features)
#         v_table = self.fc_v_table(table_features)

        # Compute attention scores
#         attended_image = F.softmax(torch.bmm(q_image.unsqueeze(1), k_table.unsqueeze(2)), dim=-1)
#         attended_image = attended_image.squeeze(1) * v_table
        attended_table = F.softmax(torch.bmm(q_table.unsqueeze(1), k_image.unsqueeze(2)), dim=-1) 
        attended_table = attended_table.squeeze(1) * v_image

        combined_features = torch.cat([image_features, table_features, attended_table], dim=1)

        return combined_features

class CombinedModel(nn.Module):
    def __init__(self, config):
        super(CombinedModel, self).__init__()

        self.num_event = config["num_event"]
        self.num_category = config["num_category"]
        self.hidden_dim = config["fc"]["hidden_dim"]
        self.num_layers = config["fc"]["num_layers"]
        self.active_fn = config["fc"]["active_fn"]
        self.dropout_rate = config["fc"]["dropout_rate"]
        self.mode = config["mode"] == "train"
        
        if config["image_use"]:
            self.table_processor = TableDataProcessor(41, config["table"]["hidden_dim"], config["table"]["output_dim"], config["table"]["active_fn"])
        else:
            self.table_processor = TableDataProcessor(10, config["table"]["hidden_dim"], config["table"]["output_dim"], config["table"]["active_fn"])
        self.time_extractor = TimeFeatureExtractor(input_dim=1, hidden_dims=config["time"]["hidden_dim"])
        self.cross_attention = CrossAttention()
        
        
        if config["image_use"]:
            self.sub_networks = nn.ModuleList([
                create_FCNet(384, self.hidden_dim, self.hidden_dim, self.active_fn, self.num_layers, self.dropout_rate) 
                for _ in range(self.num_event)
             ])
        else:
            self.sub_networks = nn.ModuleList([
                create_FCNet(config["table"]["output_dim"], self.hidden_dim, self.hidden_dim, self.active_fn, self.num_layers, self.dropout_rate) 
                for _ in range(self.num_event)
             ])

        self.output_fc = nn.Linear(self.num_event * self.hidden_dim, self.num_event)
        self.output_softmax = nn.Softmax(dim=1)

        self.nnunet = UNet3D(in_channels = 1, out_channels = 64)
        self.image_fc = nn.Linear(128, 1)

    def forward(self, image_data, table_data, time):
        
        time = time.view(-1, 1)
        table_data = torch.cat([table_data, time], dim = 1)
        features = self.table_processor(table_data)
        
        if image_data is not None:
            image_features = self.nnunet(image_data)
            batch_size, channels, _, _, _ = image_features.size()
            image_features = image_features.view(batch_size, channels, -1)
            image_features = self.image_fc(image_features).squeeze(2)
            features = self.cross_attention(image_features, features)

        out = []
        for sub_net in self.sub_networks:
            cs_out = sub_net(features)
            out.append(cs_out)

        out = torch.stack(out, dim = 1)
        out = out.view(out.size(0), -1)
        # out = F.dropout(out, p = self.dropout_rate, training=self.mode)

        out = self.output_fc(out)
        out = out.view(out.size(0), self.num_event)
#         out = torch.sigmoid(out)

        return out