import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from .dataset import load_dataset
from pycox.models import CoxTime
from sklearn.model_selection import train_test_split
from lifelines import KaplanMeierFitter

def preprocess_metadata(config):
    
    if config["dataset_name"] == "HNSCC":
        metadata = pd.read_csv("/home/users/s1155198347/large-data/dataset/HNSCC_metadata.xlsx")
        
        train_df, test_df = train_test_split(metadata, test_size=0.2, stratify=metadata['Cause of Death'])
        train_df = train_df.sort_values(by='Follow up duration').reset_index(drop=True)
        test_df = test_df.sort_values(by='Follow up duration').reset_index(drop=True)
        
        labtrans = CoxTime.label_transform()
        train_df['Follow up duration'], train_df['Cause of Death'] = labtrans.fit_transform(
            train_df['Follow up duration'].values, train_df['Cause of Death'].values)
        config["num_features"] = metadata.shape[1] - 2
        
        train_df['risk_set_forward'] = None
        train_df['risk_set_backward'] = None
        test_df['risk_set_forward'] = None
        test_df['risk_set_backward'] = None
        
        event_rows = train_df[train_df['Cause of Death'] != 0]

        for index, row in event_rows.iterrows():
            time = row['Follow up duration']
            label = row['Cause of Death']
            current_idx = index

            # 查找时间之后的样本，且 Cause of Death 相同
            risk_candidates_forward = train_df[(train_df['Follow up duration'] > time)]
            if not risk_candidates_forward.empty:
                risk_sample_forward = risk_candidates_forward.sample(n=1)
                risk_idx_forward = risk_sample_forward.index[0]
                train_df.at[current_idx, 'risk_set_forward'] = risk_idx_forward
            else:
                train_df.at[current_idx, 'risk_set_forward'] = None

            # 查找时间之前的样本，且 Cause of Death 不同
            risk_candidates_backward = train_df[
                (train_df['Follow up duration'] < time) & (train_df["Cause of Death"] != 0) & (train_df['Cause of Death'] != label)]
            if not risk_candidates_backward.empty:
                risk_sample_backward = risk_candidates_backward.sample(n=1)
                risk_idx_backward = risk_sample_backward.index[0]
                train_df.at[current_idx, 'risk_set_backward'] = risk_idx_backward
            else:
                train_df.at[current_idx, 'risk_set_backward'] = None

        return train_df, test_df, labtrans                              


    elif config["dataset_name"] == "SYNTHETIC_COMPETING":
        df = load_dataset(dataset='SYNTHETIC_COMPETING', path='./', normalize=False)
        df1 = pd.DataFrame(df[0])
        df1.columns = df[3]
        df1['Follow up duration'], df1['Cause of Death'] = df[1], df[2]

        # 将数据集拆分为训练集和验证集
        train_df, test_df = train_test_split(df1, test_size=0.2, stratify=df1['Cause of Death'])
        train_df = train_df.sort_values(by='Follow up duration').reset_index(drop=True)
        test_df = test_df.sort_values(by='Follow up duration').reset_index(drop=True)

        labtrans = CoxTime.label_transform()
        train_df['Follow up duration'], train_df['Cause of Death'] = labtrans.fit_transform(
            train_df['Follow up duration'].values, train_df['Cause of Death'].values)
        config["num_features"] = df1.shape[1] - 1

        train_df['risk_set_forward'] = None
        train_df['risk_set_backward'] = None
        test_df['risk_set_forward'] = None
        test_df['risk_set_backward'] = None

        event_rows = train_df[train_df['Cause of Death'] != 0]

        for index, row in event_rows.iterrows():
            time = row['Follow up duration']
            label = row['Cause of Death']
            current_idx = index

            # 查找时间之后的样本，且 Cause of Death 相同
            risk_candidates_forward = train_df[(train_df['Follow up duration'] > time)]
            if not risk_candidates_forward.empty:
                risk_sample_forward = risk_candidates_forward.sample(n=1)
                risk_idx_forward = risk_sample_forward.index[0]
                train_df.at[current_idx, 'risk_set_forward'] = risk_idx_forward
            else:
                train_df.at[current_idx, 'risk_set_forward'] = None

            # 查找时间之前的样本，且 Cause of Death 不同
            risk_candidates_backward = train_df[
                (train_df['Follow up duration'] < time) & (train_df["Cause of Death"] != 0) & (train_df['Cause of Death'] != label)]
            if not risk_candidates_backward.empty:
                risk_sample_backward = risk_candidates_backward.sample(n=1)
                risk_idx_backward = risk_sample_backward.index[0]
                train_df.at[current_idx, 'risk_set_backward'] = risk_idx_backward
            else:
                train_df.at[current_idx, 'risk_set_backward'] = None

        return train_df, test_df, labtrans



    elif config["dataset_name"] == "METABRIC":
        # 加载并处理 METABRIC 数据集
        df = load_dataset(dataset='METABRIC', path='./', normalize=False)
        df1 = pd.DataFrame(df[0])
        df1.columns = df[3]
        df1['Follow up duration'], df1['Cause of Death'] = df[1], df[2]
        config["num_features"] = df1.shape[1] - 1

        # 将数据集拆分为训练集和验证集
        train_df, test_df = train_test_split(df1, test_size=0.2, stratify=df1['Cause of Death'])
        train_df = train_df.sort_values(by='Follow up duration').reset_index(drop=True)
        test_df = test_df.sort_values(by='Follow up duration').reset_index(drop=True)

        scaler = StandardScaler()
        columns_to_scale = ['MKI67', 'EGFR', 'PGR', 'ERBB2', 'Age at diagnosis']
        train_df[columns_to_scale] = scaler.fit_transform(train_df[columns_to_scale])
        test_df[columns_to_scale] = scaler.transform(test_df[columns_to_scale])

        labtrans = CoxTime.label_transform()
        train_df['Follow up duration'], train_df['Cause of Death'] = labtrans.fit_transform(
            train_df['Follow up duration'].values, train_df['Cause of Death'].values)
        config["num_features"] = df1.shape[1] - 1

        # 为训练集和验证集添加 'risk_set' 列
        train_df['risk_set_forward'] = None
        test_df['risk_set_forward'] = None

        event_rows = train_df[train_df['Cause of Death'] != 0]
        for index, row in event_rows.iterrows():
            time = row['Follow up duration']
            risk_candidates = train_df[(train_df['Follow up duration'] > time)]
            if not risk_candidates.empty:
                risk_sample = risk_candidates.sample(n=1)
                risk_idx = risk_sample.index[0]
                train_df.at[index, 'risk_set_forward'] = risk_idx
            else:
                train_df.at[index, 'risk_set_forward'] = None

        return train_df, test_df, labtrans
    
    
    elif config["dataset_name"] == "SEER":
        # 加载并处理 METABRIC 数据集
        df = load_dataset(dataset='SEER', path='./', normalize=False)
        df1 = pd.DataFrame(df[0])
        df1.columns = df[3]
        df1['Follow up duration'], df1['Cause of Death'] = df[1], df[2]
        config["num_features"] = df1.shape[1] - 1

        # 将数据集拆分为训练集和验证集
        train_df, test_df = train_test_split(df1, test_size=0.2, stratify=df1['Cause of Death'])
        train_df = train_df.sort_values(by='Follow up duration').reset_index(drop=True)
        test_df = test_df.sort_values(by='Follow up duration').reset_index(drop=True)


        labtrans = CoxTime.label_transform()
        train_df['Follow up duration'], train_df['Cause of Death'] = labtrans.fit_transform(
            train_df['Follow up duration'].values, train_df['Cause of Death'].values)
        config["num_features"] = df1.shape[1] - 1

        # 为训练集和验证集添加 'risk_set' 列
        train_df['risk_set_forward'] = None
        test_df['risk_set_forward'] = None

        event_rows = train_df[train_df['Cause of Death'] != 0]
        for index, row in event_rows.iterrows():
            time = row['Follow up duration']
            risk_candidates = train_df[(train_df['Follow up duration'] > time)]
            if not risk_candidates.empty:
                risk_sample = risk_candidates.sample(n=1)
                risk_idx = risk_sample.index[0]
                train_df.at[index, 'risk_set_forward'] = risk_idx
            else:
                train_df.at[index, 'risk_set_forward'] = None

        return train_df, test_df, labtrans
        
        
        
        
        
        