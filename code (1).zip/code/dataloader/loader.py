import os
import pydicom
import numpy as np
import torch
from torch.utils.data import Dataset
from torch.utils.data import DataLoader, random_split
import pandas as pd
from lifelines import KaplanMeierFitter


class DICOMDataset(Dataset):
    def __init__(self, dataframe, transform=None, metadata=None):
        self.dataframe = dataframe
        self.transform = transform
        self.metadata = metadata
        self.kmf = KaplanMeierFitter()
        self.kmf.fit(durations=self.dataframe["Follow up duration"], event_observed=self.dataframe["Cause of Death"])

    def __len__(self):
        return len(self.dataframe)
    
    def create_tensor_or_none(d, dtype=torch.float32, shape=(2,2)):
        print("d:", d)
        if d is None:
            return torch.zeros(shape, dtype=dtype)
        else:
            return torch.tensor(d, dtype=dtype)

    def __getitem__(self, idx):
        label = np.array([self.dataframe["Cause of Death"].iloc[idx]])
        time = np.array([self.dataframe["Follow up duration"].iloc[idx]])
        features = self.dataframe.drop(
            columns=["Cause of Death", "Follow up duration", "risk_set", "risk_set_forward", "risk_set_backward", "File Location"],
            errors='ignore').iloc[idx, :].values


        risk_idx_forward = self.dataframe["risk_set_forward"].iloc[idx]
        risk_features_forward = get_risk_features(risk_idx_forward, features, self.metadata)
        
        
        if "risk_set_backward" in self.dataframe.columns:
            risk_idx_backward = self.dataframe["risk_set_backward"].iloc[idx]
            risk_features_backward = get_risk_features(risk_idx_backward, features, self.metadata)
            g_value = self.kmf.predict(time) / self.kmf.predict(self.metadata["Follow up duration"].loc[risk_idx_backward]) if pd.notna(risk_idx_backward) else 1
            features = np.stack([features, risk_features_forward, risk_features_backward], axis=0)
            times = np.stack([time, time, time], axis = 0)
            labels = np.stack([label, label, label], axis = 0)
        else:
            features = np.stack([features, risk_features_forward], axis = 0)
            times = np.stack([time, time], axis = 0)
            labels = np.stack([label, label], axis = 0)
            g_value = None
            


        if "File Location" in self.dataframe.columns:
            folder_path = self.dataframe["File Location"].iloc[idx]
            image = load_dicom_images(folder_path)
            image = self.transform({"image":image})["image"]
            folder_path_forward = self.metadata["File Location"].loc[risk_idx_forward] if pd.notna(risk_idx_forward) else folder_path
            image_forward = load_dicom_images(folder_path_forward)
            image_forward = self.transform({"image":image_forward})["image"]
                
            if "risk_set_backward" in self.dataframe.columns:
                folder_path_backward = self.metadata["File Location"].loc[risk_idx_backward] if pd.notna(risk_idx_backward) else folder_path
                image_backward = load_dicom_images(folder_path_backward)
                image_backward = self.transform({"image":image_backward})["image"]
                image = torch.cat([image, image_forward, image_backward], dim=0)
            else:
                image = torch.cat([image, image_forward], dim=0)
                
        else:
            image = None
            
        data = {
            "image" : create_tensor_or_none(image),
            "label": torch.tensor(labels, dtype=torch.float32),
            "time": torch.tensor(times, dtype=torch.float32),
            "support data": torch.tensor(features, dtype=torch.float32),
            "g_value" : create_tensor_or_none(g_value)
        }
       

        if self.transform:
            data = self.transform(data)

        return data


def split_dataset(dataset, split_ratio=0.2):
    val_size = round(split_ratio * len(dataset))
    train_size = len(dataset) - val_size
    return random_split(dataset, [train_size, val_size])


# 数据加载器创建函数
def create_dataloaders(train_metadata, val_metadata = None, transforms = None, config = None):

    train_subset = train_metadata[(train_metadata["Cause of Death"] != 0)]
    train_dataset = DICOMDataset(train_subset, transform=transforms, metadata=train_metadata)
    train_dataloader = DataLoader(train_dataset, batch_size=config["batch_size"], shuffle=True)

    val_dataset = DICOMDataset(val_metadata, transform=transforms, metadata=val_metadata)
    val_dataloader = DataLoader(val_dataset, batch_size=config["batch_size"], shuffle=False)

    return train_dataloader, val_dataloader



def create_tensor_or_none(d, dtype=torch.float32, shape=(2)):
    if d is None:
        return torch.zeros(shape, dtype=dtype)
    else:
        return torch.tensor(d, dtype=dtype)
    
    
def get_risk_features(risk_idx, features, metadata):
    if pd.notna(risk_idx):
        return metadata.drop(
            columns=["Cause of Death", "Follow up duration", "risk_set", "risk_set_forward", 
                     "risk_set_backward", "File Location"], errors='ignore').loc[risk_idx, :].values
    else:
        return features
    
def load_dicom_images(folder_path):
    dicom_files = [os.path.join(folder_path, f) for f in sorted(os.listdir(folder_path)) if f.endswith('.dcm')]
    slices = [pydicom.dcmread(dicom_file).pixel_array.astype(np.float32) for dicom_file in dicom_files]
    return torch.tensor(np.stack(slices, axis=0)).unsqueeze(0)

