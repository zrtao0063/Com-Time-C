import numpy as np
from monai.transforms import (
    MapTransform,
    ScaleIntensityRanged,
    NormalizeIntensity,
    NormalizeIntensityd,
    ToTensord,
    ResizeD,
    SpatialPadd,
    RandZoomd,
    RandGaussianNoised,
    RandGaussianSmoothd,
    RandScaleIntensityd,
    RandFlipd,
    CastToTyped,
    EnsureTyped,
    Compose
)
from monai.transforms.utils import MapTransform

class Preprocess(MapTransform):
    def __init__(self, keys, intensityproperties, target_dtype=np.float32) -> None:
        super().__init__(keys)
        self.intensityproperties = intensityproperties
        self.target_dtype = target_dtype

    def __call__(self, data):
        image = data["image"]

        # Apply custom CTNormalization
        image = self.ct_normalization(image)

        data["image"] = image
        return data

    def ct_normalization(self, image: np.ndarray) -> np.ndarray:
        mean_intensity = self.intensityproperties['mean']
        std_intensity = self.intensityproperties['std']
        lower_bound = self.intensityproperties['percentile_00_5']
        upper_bound = self.intensityproperties['percentile_99_5']

        # Convert to target dtype and clip values
        image = torch.clamp(image, lower_bound, upper_bound, out=image)
        image -= mean_intensity
        image /= max(std_intensity, 1e-8)
        return image


def get_task_transforms(config):
    transforms = [
        # Preprocess(keys=["image"], intensityproperties = config['intensityproperties']),
        ScaleIntensityRanged(
            keys=['image'],
            a_min=config['intensityproperties']['percentile_00_5'],
            a_max=config['intensityproperties']['percentile_99_5'],
            b_min=0.0,
            b_max=1.0,
            clip=True,
        ),
        NormalizeIntensityd(
            keys=['image'],
            subtrahend=config['intensityproperties']['mean'],
            divisor=config['intensityproperties']['std'],
            nonzero=False,
            channel_wise=False
        ),
        ToTensord(keys="image"),
        ResizeD(keys="image", spatial_size=config["patch_size"]),
    ]

    if config["mode"] == "train":
        transforms += [
            SpatialPadd(keys=["image"], spatial_size=config["patch_size"]),
            RandZoomd(
                keys=["image"],
                min_zoom=1,
                max_zoom=1.2,
                mode="trilinear",
                align_corners=True,
                prob=0.15,
            ),
            RandGaussianNoised(keys=["image"], std=0.01, prob=0.15),
            RandGaussianSmoothd(
                keys=["image"],
                sigma_x=(0.5, 1.15),
                sigma_y=(0.5, 1.15),
                sigma_z=(0.5, 1.15),
                prob=0.15,
            ),
            RandScaleIntensityd(keys=["image"], factors=0.3, prob=0.15),
            RandFlipd(keys=["image"], spatial_axis=[0], prob=0.5),
            RandFlipd(keys=["image"], spatial_axis=[1], prob=0.5),
            RandFlipd(keys=["image"], spatial_axis=[2], prob=0.5),
        ]

    transforms += [
        CastToTyped(keys=["image"], dtype=np.float32),
        EnsureTyped(keys=["image"]),
    ]

    return Compose(transforms)
