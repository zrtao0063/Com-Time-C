import os
import pydicom
import numpy as np
import torch
from torch.utils.data import Dataset
from monai.transforms import Compose

class DICOMDataset(Dataset):
    def __init__(self, dataframe, transform=None):
        self.dataframe = dataframe
        self.transform = transform

    def __len__(self):
        return len(self.dataframe)

    def __getitem__(self, idx):
        
        label = self.dataframe["Cause of Death"][idx]
        time = self.dataframe["Follow up duration"][idx]
        features = self.dataframe.drop(columns=["Cause of Death", "Follow up duration"]).iloc[idx, :].values
        
        if "File Location" in self.dataframe.columns:
            folder_path = self.dataframe["File Location"][idx]
            dicom_files = [os.path.join(folder_path, f) for f in sorted(os.listdir(folder_path)) if f.endswith('.dcm')]

            slices = []
            for dicom_file in dicom_files:
                ds = pydicom.dcmread(dicom_file)
                slices.append(ds.pixel_array.astype(np.float32))

            image = np.stack(slices, axis=0)
            image = torch.tensor(image).unsqueeze(0)
            
            data = {
                "image": image,
                "label": torch.tensor(label, dtype=torch.float32),
                "time": torch.tensor(time, dtype=torch.float32), 
                "support data": torch.tensor(
                    list(self.dataframe.iloc[idx, 7:]),
                    dtype=torch.float32)
            }
        
        else:
            data = {
                "label": torch.tensor(label, dtype=torch.float32),
                "time": torch.tensor(time, dtype=torch.float32), 
                "support data": torch.tensor(features, dtype=torch.float32)
            }

        if self.transform:
            data = self.transform(data)
        
        return data