import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from .dataset import load_dataset
from pycox.models import CoxTime

def preprocess_metadata(config):
    
    if config["dataset_name"] == "image_data":
        # Load the metadata
        metadata_path = config['base']['metadata_path']
        infodata_path = config['base']['infodata_path']
        
        metadata = pd.read_excel(metadata_path)
        metadata['File Location'] = [path.replace(".\\HNSCC", "./dataset/HNSCC").replace("\\", "/")
                                     for path in metadata['File Location']]
        infodata = pd.read_excel(infodata_path)
        metadata = pd.merge(metadata, infodata, left_on='Subject ID', right_on='TCIA PatientID', how='left')

        columns_to_onehot = ['Sex', 'Diag', 'Site', 'Platinum-based chemotherapy', 'Received Concurrent Chemoradiotherapy', 'CCRT Chemotherapy Regimen', 
                        'Unplanned Additional Oncologic Treatment', 'PreRT Skeletal Muscle status', 'PostRT Skeletal Muscle status']
        metadata = pd.get_dummies(metadata, columns=columns_to_onehot, prefix=columns_to_onehot)

        cause_of_death_mapping = {
        'Alive': 0,
        'HN Cancer': 1,
        'Non cancer related': 2,
        'Other Cancer': 2,
        'Other cancer': 2,
        'Unknown': 2,
        }
        grade_mapping = {
            'undiff.': 0,
            'poorly diff.': 1,
            'moderately to poorly diff.': 2,
            'moderately diff.': 3,
            'well to moderately diff.': 4,
            'Well to moderately diff.': 4,
            'well diff.': 5
        }
        stage_mapping = {
            'I': 1,
            "II": 2,
            "III": 3,
            'IVA': 4,
            'IVB': 4
        }
        metadata['Cause of Death'] = metadata['Cause of Death'].map(cause_of_death_mapping)
        metadata['Grade'] = metadata['Grade'].map(grade_mapping)
        metadata['Stage'] = metadata['Stage'].map(stage_mapping)

        # Extract the columns for PCA
        df_pca_input = metadata.iloc[:, list(range(4, 9)) + list(range(12, metadata.shape[1]))]

        # Standardize the data before applying PCA
        scaler = StandardScaler()
        df_pca_standardized = scaler.fit_transform(df_pca_input)

        # Apply PCA to reduce to 40 dimensions
        pca = PCA(n_components=40)
        df_pca_result = pca.fit_transform(df_pca_standardized)

        # Convert the PCA result to a DataFrame
        df_pca_result = pd.DataFrame(df_pca_result, columns=[f'PC{i+1}' for i in range(40)])

        # Extract the columns not used in PCA (including columns 9 to 11)
        df_remaining = pd.concat([metadata.iloc[:, :4], metadata.iloc[:, 9:12]], axis=1)
        # Combine the PCA results with the remaining columns
        df_final = pd.concat([df_remaining, df_pca_result], axis=1)

        return df_final


    elif config["dataset_name"] == "SYNTHETIC_COMPETING":
        df = load_dataset(dataset='SYNTHETIC_COMPETING', path='./', normalize=True)
        df1 = pd.DataFrame(df[0])
        df1.columns = df[3]
        df1['Follow up duration'] = df[1]
        df1['Cause of Death'] = df[2]
        return df1

    elif config["dataset_name"] == "METABRIC":
        df = load_dataset(dataset='METABRIC', path='./', normalize=True)
        df1 = pd.DataFrame(df[0])
        df1.columns = df[3]
        labtrans = CoxTime.label_transform()
        df1['Follow up duration'], df1['Cause of Death'] = labtrans.fit_transform(df[1], df[2])
        scaler = StandardScaler()
        columns_to_scale = ['MKI67', 'EGFR', 'PGR', 'ERBB2', 'Age at diagnosis']
        df1[columns_to_scale] = scaler.fit_transform(df1[columns_to_scale])
        return df1
        
        
        
        
        
        
        