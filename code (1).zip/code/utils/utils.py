import torch
import numpy as np
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
import os
import pydicom

def predict_cumulative_hazards(image, table, baseline_hazards, model, device):
    def expg_at_time(t):
        t = torch.tensor(t).repeat(n_cols).reshape(-1, 1).float().to(device)
        return np.exp(model(image, table, t).cpu())

    n_rows, n_cols = baseline_hazards.shape[0], table.size(0)
    cumulative_hazards_dict = {}

    hazards_all_time = np.empty((n_rows, n_cols, baseline_hazards.shape[1]))  # 预分配一个三维数组，存储所有时间点和所有列的hazard

    for idx, t in enumerate(baseline_hazards.index):
        expg_values = expg_at_time(t)  # 只调用一次expg_at_time
        hazards_all_time[idx, :, :] = expg_values

    # 处理每一列的数据
    for i, column in enumerate(baseline_hazards.columns):
        hazards = hazards_all_time[:, :, i]
        hazards[baseline_hazards[column].values == 0] = 0
        hazards *= baseline_hazards[column].values.reshape(-1, 1)
        cumulative_hazards_dict[column] = pd.DataFrame(hazards, index=baseline_hazards.index).cumsum()

    return cumulative_hazards_dict


def manual_groupby_sum(df):
    grouped_events = {}
    for _, row in df.iterrows():
        duration = row['Follow up duration']
        event = row['Cause of Death']
        if duration in grouped_events:
            grouped_events[duration] += event
        else:
            grouped_events[duration] = event
    result_df = pd.DataFrame(list(grouped_events.items()), columns=['Follow up duration', 'Cause of Death'])
    result_df = result_df.sort_values(by='Follow up duration').reset_index(drop=True)
    return result_df

def compute_baseline_hazards(train_df, model, device, transforms, max_duration=np.inf):
    def compute_expg_at_risk(ix, t):
        sub = train_df.iloc[ix:]
        tables = sub.drop(
            columns=["Cause of Death", "Follow up duration", "risk_set", "risk_set_forward", "risk_set_backward", "File Location"],
            errors='ignore').values
        tables_tensor = torch.tensor(tables, dtype=torch.float32)
        
        if "File Location" in sub.columns:
            image_paths = sub["File Location"].values  # 假设 File Location 列包含图像文件的路径
            images = []
            for path in image_paths:
                dicom_files = [os.path.join(path, f) for f in sorted(os.listdir(path)) if f.endswith('.dcm')]
                slices = [pydicom.dcmread(f).pixel_array.astype(np.float32) for f in dicom_files]
                image = torch.tensor(np.stack(slices, axis=0)).unsqueeze(0)
                image = transforms({"image":image})["image"]
                images.append(image)  # 扩展为 5D

            image_tensor = torch.cat(images, dim=0)

            dataset = TensorDataset(tables_tensor, image_tensor)
            dataloader = DataLoader(dataset, batch_size=256, shuffle=False)
        else:
            dataset = TensorDataset(tables_tensor)
            dataloader = DataLoader(dataset, batch_size=256, shuffle=False)

        total_exp_g_1 = 0.0
        total_exp_g_2 = 0.0  # 用于处理两个输出值的情况

#         model.eval()
#         with torch.no_grad():
        for batch in dataloader:
            if "File Location" in sub.columns:
                image_batch = batch[1].to(device)
            else:
                image_batch = None
            tables_batch = batch[0].to(device)
            t_batch = torch.tensor(np.repeat(t, len(tables_batch)).reshape(-1, 1).astype('float32')).to(device)

            # 获取模型的输出
            outputs = model(image_batch, tables_batch, t_batch)

            # 判断模型输出是否为两个值，分别计算
            if outputs.shape[1] == 2:
                exp_g_1 = torch.exp(outputs[:,0])
                exp_g_2 = torch.exp(outputs[:,1])

                total_exp_g_1 += exp_g_1.sum().item()
                total_exp_g_2 += exp_g_2.sum().item()
            else:
                exp_g_1 = torch.exp(outputs)
                total_exp_g_1 += exp_g_1.sum().item()

        # 根据是否有两个输出返回结果
        if total_exp_g_2 != 0:
            return total_exp_g_1, total_exp_g_2
        else:
            return total_exp_g_1

    # 计算 at_risk_sum，处理一列和两列的情况
    num_events = len(np.unique(train_df['Cause of Death'])) - 1
    filtered_df = train_df[train_df["Cause of Death"] != 0]
    times = np.unique(filtered_df["Follow up duration"].values)
    first_idx_for_times = [filtered_df[filtered_df["Follow up duration"] == t].index[0] for t in times]
    at_risk_sum_list = [compute_expg_at_risk(ix, t) for ix, t in zip(first_idx_for_times, times)]

    # 如果模型输出一个值
    if isinstance(at_risk_sum_list[0], tuple):
        at_risk_sum = pd.DataFrame({
            'Follow up duration': times,
            'at_risk_sum_1': [x[0] for x in at_risk_sum_list],
            'at_risk_sum_2': [x[1] for x in at_risk_sum_list]
        })
    else:
        at_risk_sum = pd.DataFrame({
            'Follow up duration': times,
            'at_risk_sum': at_risk_sum_list
        })
    events = manual_groupby_sum(train_df)

    base_haz_all = pd.DataFrame()

    for i in range(num_events):
        df_temp = events.merge(at_risk_sum, on="Follow up duration", how='left', sort=True)
        df_temp["baseline_hazards"] = df_temp["Cause of Death"].astype(np.float32) / df_temp.iloc[:,(2+i)].astype(np.float32)
        df_temp['baseline_hazards'].interpolate(method='linear', inplace=True)
        df_temp['baseline_hazards'].fillna(0., inplace=True)
        base_haz_all[f'base_haz_{i+1}'] = df_temp["baseline_hazards"].astype(np.float32)

    base_haz_all.index = df_temp["Follow up duration"]
    return base_haz_all