import math
from torch.optim.lr_scheduler import _LRScheduler, LambdaLR

class StepDecay(_LRScheduler):
    def __init__(self, optimizer, step_size, gamma=0.1, min_lr=1e-6, last_epoch=-1, verbose=False):
        self.step_size = step_size
        self.gamma = gamma
        self.min_lr = min_lr
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self):
        return [max(base_lr * (self.gamma ** (self.last_epoch // self.step_size)), self.min_lr)
                for base_lr in self.base_lrs]

class PolynomialDecay(_LRScheduler):
    def __init__(self, optimizer, max_decay_steps, end_learning_rate=1e-8, power=1.0, last_epoch=-1, verbose=False):
        self.max_decay_steps = max_decay_steps
        self.end_learning_rate = end_learning_rate
        self.power = power
        super(PolynomialDecay, self).__init__(optimizer, last_epoch, verbose)

    def get_lr(self):
        step = min(self.last_epoch, self.max_decay_steps)
        factor = (1 - step / self.max_decay_steps) ** self.power
        return [(base_lr - self.end_learning_rate) * factor + self.end_learning_rate for base_lr in self.base_lrs]

class WarmupCosineSchedule(LambdaLR):
    def __init__(self, optimizer, warmup_steps, t_total, cycles=0.5, last_epoch=-1) -> None:
        self.warmup_steps = warmup_steps
        self.t_total = t_total
        self.cycles = cycles
        super(WarmupCosineSchedule, self).__init__(optimizer, self.lr_lambda, last_epoch)

    def lr_lambda(self, step):
        if step < self.warmup_steps:
            return float(step) / float(max(1.0, self.warmup_steps))
        progress = float(step - self.warmup_steps) / float(max(1, self.t_total - self.warmup_steps))
        return max(0.0, 0.5 * (1.0 + math.cos(math.pi * float(self.cycles) * 2.0 * progress)))

class CosineAnnealingThenConstantLR(_LRScheduler):
    def __init__(self, optimizer, T_max, min_lr=1e-6, last_epoch=-1, verbose=False):
        self.T_max = T_max
        self.min_lr = min_lr
        super(CosineAnnealingThenConstantLR, self).__init__(optimizer, last_epoch, verbose)

    def get_lr(self):
        if self.last_epoch < self.T_max:
            return [base_lr * (1 + math.cos(math.pi * self.last_epoch / self.T_max)) / 2
                    for base_lr in self.base_lrs]
        else:
            return [self.min_lr for _ in self.base_lrs]

def instantiate_scheduler(config, optimizer):
    if config.opt_scheduler == "CosineAnnealingLR":
        scheduler = optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=config.opt_scheduler_T_max, eta_min=1e-8
        )
    elif config.opt_scheduler == "StepLR":
        scheduler = StepDecay(
            optimizer, step_size=config.opt_step_size, gamma=config.opt_gamma
        )
    elif config.opt_scheduler == "PolynomialDecay":
        scheduler = PolynomialDecay(
            optimizer, max_decay_steps=config.opt_max_decay_steps,
            end_learning_rate=float(config.opt_end_learning_rate), power=config.opt_power
        )
    elif config.opt_scheduler == "warmup_cosine":
        scheduler = WarmupCosineSchedule(
            optimizer, warmup_steps=config.opt_warmup_steps, t_total=config.opt_scheduler_T_max
        )
    elif config.opt_scheduler == "CosineAnnealingThenConstantLR":
        scheduler = CosineAnnealingThenConstantLR(
            optimizer, T_max=config.opt_scheduler_T_max, min_lr=config.opt_end_learning_rate
        )
    else:
        raise ValueError(f"Got {config.opt_scheduler=}")
    return scheduler