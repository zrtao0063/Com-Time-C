import os
import tempfile
import json
import logging
import argparse
import yaml
import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
from pycox.evaluation import EvalSurv
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split
from datetime import datetime
from dataloader import DICOMDataset, preprocess_metadata, get_task_transforms
from models import CombinedModel
from loss import TotalLoss

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# 创建日志记录器
def setup_logging(log_dir, log_level=logging.INFO):
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, 'train.log')
    logging.basicConfig(filename=log_path,
                        filemode='a',
                        format='%(asctime)s - %(levelname)s - %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S',
                        level=log_level)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    logging.getLogger().addHandler(console_handler)

# 配置加载函数
def load_config(config_path):
    def include_constructor(loader, node):
        current_file_path = loader.name
        base_folder = os.path.dirname(current_file_path)
        included_file = os.path.join(base_folder, loader.construct_scalar(node))

        with open(included_file, "r") as file:
            return yaml.load(file, Loader=yaml.Loader)

    yaml.Loader.add_constructor("!include", include_constructor)

    with open(config_path, "r") as f:
        config = yaml.load(f, Loader=yaml.Loader)

    return config

# 数据集划分函数
def split_dataset(dataset, split_ratio=0.18):
    val_size = round(split_ratio * len(dataset))
    train_size = len(dataset) - val_size
    return random_split(dataset, [train_size, val_size])

# 数据加载器创建函数
def create_dataloaders_dicom(metadata, transforms, split_ratio=0.2):
    train_dataloaders = {}
    val_datasets = []
    
    for label in metadata['Cause of Death'].unique():
        dataset = DICOMDataset(metadata[metadata["Cause of Death"] == label].reset_index(drop=True), transform=transforms)
        train_dataset, val_dataset = split_dataset(dataset, split_ratio)
        
        train_dataloaders[label] = DataLoader(train_dataset, batch_size=256 if label == 0 else 128, shuffle=True)
        val_datasets.append(val_dataset)

    combined_val_dataset = torch.utils.data.ConcatDataset(val_datasets)
    val_dataloader = DataLoader(combined_val_dataset, batch_size=1, shuffle=False)
    
    return train_dataloaders, val_dataloader



def compute_baseline_hazards(input, durations, events, max_duration=np.inf):

    expg = np.exp(input)
    unique_durations = np.unique(durations)
    baseline_hazards = np.zeros(len(unique_durations))
    
    for i, time in enumerate(unique_durations):
        # 计算该时间点的 `expg` 总和和事件数总和
        mask = durations == time
        expg_sum = np.sum(expg[mask])
        event_sum = np.sum(events[mask])
        
        # 如果 `expg_sum` 为零，则基线危险率为零
        if expg_sum > 0:
            baseline_hazards[i] = event_sum / expg_sum
        else:
            baseline_hazards[i] = 0
    
    # 计算累计 `expg`
    cumulative_expg = np.zeros(len(unique_durations))
    cumulative_expg[0] = expg[durations == unique_durations[0]].sum()
    
    for i in range(1, len(unique_durations)):
        cumulative_expg[i] = cumulative_expg[i - 1] + expg[durations == unique_durations[i]].sum()
    
    # 计算基线危险率
    baseline_hazards = np.zeros_like(cumulative_expg)
    for i, time in enumerate(unique_durations):
        mask = durations <= time
        expg_cumulative = np.sum(expg[mask])
        event_cumulative = np.sum(events[mask])
        if expg_cumulative > 0:
            baseline_hazards[i] = event_cumulative / expg_cumulative
        else:
            baseline_hazards[i] = 0

    # 限制最大持续时间
    if max_duration is not np.inf:
        valid_mask = unique_durations <= max_duration
        unique_durations = unique_durations[valid_mask]
        baseline_hazards = baseline_hazards[valid_mask]

    return pd.DataFrame({"time": unique_durations, "bch": baseline_hazards})




# 训练函数
def train(model, metadata, transforms, config):
  
    model.train()
    loss_fn = TotalLoss(loss_weights=config["loss_weights"])
    optimizer = optim.Adam(model.parameters(), lr=config["learning_rate"])

    best_loss = float('inf')
    results_df = pd.DataFrame(columns=['expg', 'label', 'time'])

    for epoch in range(config["num_epochs"]):
        running_loss = 0.0
        train_dataloaders, val_dataloaders = create_dataloaders_dicom(metadata, transforms)
        
        for i, batches in enumerate(zip(*train_dataloaders.values())):
            images, tables, labels, times = [], [], [], []
            for batch in batches:
                if config["image_use"]:
                    images.append(batch["image"])
                tables.append(batch["support data"])
                labels.append(batch["label"])
                times.append(batch["time"])

            # 根据是否使用image模态来进行张量的拼接
            if config["image_use"]:
                image = torch.cat(images, dim=0)
            table = torch.cat(tables, dim=0)
            label = torch.cat(labels, dim=0)
            time = torch.cat(times, dim=0)

            optimizer.zero_grad()
            loss, expg = loss_fn(
                model=model,
                image=image if config["image_use"] else None,  # 传递None如果不使用image模态
                table=table,
                time=time,
                label=label
            )

            loss.backward()
            optimizer.step()
            
            batch_df = pd.DataFrame({
                'expg': expg[:,0].detach().numpy(),
                'label': label.detach().numpy(),
                'time': time.detach().numpy()
            })
            results_df = pd.concat([results_df, batch_df], ignore_index=True)
            running_loss += loss.item()

        avg_loss = running_loss / len(train_dataloaders[0])
        logging.info(f"Epoch [{epoch+1}/{config['num_epochs']}], Loss: {avg_loss:.4f}")
        print(f"Epoch [{epoch+1}/{config['num_epochs']}], Loss: {avg_loss:.4f}")
        
        baseline_hazard = compute_baseline_hazards(results_df["expg"], results_df["time"], results_df["label"])

#         if avg_loss < best_loss:
#             best_loss = avg_loss
#             save_checkpoint(model, config, best_loss)
#             logging.info(f"Best model saved with loss: {best_loss:.4f}")
            
        validate(model, val_dataloaders, config, baseline_hazard)

    logging.info('Finished Training')

def validate(model, val_dataloaders, config, baseline_hazard):
    model.eval()
    baseline_time = torch.tensor(baseline_hazard["time"], dtype=torch.float32)
    baseline_bch = torch.tensor(baseline_hazard["bch"], dtype=torch.float32)
    
    pred_risk = torch.zeros((len(baseline_time), len(val_dataloaders.dataset)))
    true_time = []
    true_label = []
    
    with torch.no_grad():
        for i, batch in enumerate(val_dataloaders):
            image = batch["image"] if config["image_use"] else None
            table = batch["support data"]
            label = batch["label"]
            time = batch["time"]
            true_time.append(time)
            true_label.append(label)
            
            for t_idx, t in enumerate(baseline_time):
                time_tensor = t.repeat(table.size(0), 1)
                output = model(image, table, time_tensor)
                pred_risk[t_idx, i] = torch.exp(output[0,0]).squeeze()
    
    pred_risks = pred_risk * baseline_bch.view(-1, 1)
    surv_pred = torch.exp(-pred_risks)
            
    true_time_tensor = torch.cat(true_time).numpy()
    true_label_tensor = torch.cat(true_label).numpy()
    surv_pred_df = pd.DataFrame(surv_pred.cpu(), index=baseline_time.numpy())
    
    ev = EvalSurv(surv_pred_df, true_time_tensor, true_label_tensor, censor_surv='km')
    c_index = ev.concordance_td()

    logging.info(f"Validation C-index: {c_index:.4f}")
    print(f"Validation C-index: {c_index:.4f}")

        

# 模型检查点保存函数
def save_checkpoint(model, config, loss):
    checkpoint_dir = f"./checkpoint/{loss:.4f}"
    os.makedirs(checkpoint_dir, exist_ok=True)
    
    # 保存模型状态字典
    model_path = os.path.join(checkpoint_dir, "best_model.pth")
    torch.save(model.state_dict(), model_path)

    # 保存 config 日志文件
    config_path = os.path.join(checkpoint_dir, "config_log.json")
    with open(config_path, 'w') as config_file:
        json.dump(config, config_file, indent=4)

    logging.info(f"Checkpoint saved to {checkpoint_dir}")

# 主函数
def main(config):

    log_dir = config['log_dir'] if 'log_dir' in config else './logs'
    setup_logging(log_dir)
    
    try:
        metadata = preprocess_metadata(config)
        transforms = get_task_transforms(config) if config["image_use"] else None
        model = CombinedModel(config)
        
        train(model, metadata, transforms, config)

    except Exception as e:
        logging.exception(f"An error occurred during training: {str(e)}")
        


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Combined model training script")
    parser.add_argument('--config', default="configs/config.yaml", type=str, help="Path to the config file")
    args = parser.parse_args()

    config = load_config(args.config)
    
    logging.info("------------------configs-------------------")
    logging.info(config)
    logging.info("--------------------------------------------")
    
    main(config)
